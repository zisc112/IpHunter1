import os
from flask import Flask, request, render_template_string, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from datetime import datetime
import requests
from user_agents import parse

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
app = Flask(__name__)

# Database configuration
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
db.init_app(app)

# Model for storing IP addresses
class IPVisitor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ip_address = db.Column(db.String(45), nullable=False)
    visit_time = db.Column(db.DateTime, default=datetime.utcnow)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    city = db.Column(db.String(100), nullable=True)
    region = db.Column(db.String(100), nullable=True)
    country = db.Column(db.String(100), nullable=True)
    timezone = db.Column(db.String(50), nullable=True)
    isp = db.Column(db.String(200), nullable=True)
    device_info = db.Column(db.String(255), nullable=True)

def get_location_data(ip):
    try:
        # Clean the IP address (remove any extra parts after comma)
        ip = ip.split(',')[0].strip()

        response = requests.get(f'http://ip-api.com/json/{ip}', 
                              timeout=5,
                              headers={'User-Agent': 'Mozilla/5.0'})
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == 'success':
                return {
                    'latitude': data.get('lat'),
                    'longitude': data.get('lon'),
                    'city': data.get('city', 'Unknown'),
                    'region': data.get('regionName', 'Unknown'),
                    'country_name': data.get('country', 'Unknown'),
                    'timezone': data.get('timezone', 'Unknown'),
                    'isp': data.get('isp', 'Unknown'),
                    'org': data.get('org', 'Unknown'),
                    'as': data.get('as', 'Unknown')
                }
            print(f"Invalid location data received: {data}")
        else:
            print(f"Failed to get location data. Status code: {response.status_code}")
        return None
    except Exception as e:
        print(f"Error fetching location data: {e}")
        return None

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <title>IP Hunter</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f0f0f0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: relative;
        }
        .logo {
            position: absolute;
            top: 20px;
            left: 20px;
            width: 120px;
            height: auto;
        }
        h1 {
            color: #333;
            text-align: center;
            margin-top: 20px;
        }
        .info-box {
            text-align: center;
            margin: 20px 0;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 4px;
        }
        #map {
            height: 400px;
            width: 100%;
            margin: 20px 0;
            border-radius: 8px;
        }
        .device-info, .network-info {
            background-color: #e9ecef;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
        }
        .device-info h3, .network-info h3 {
            color: #495057;
            margin-bottom: 20px;
            text-align: center;
        }
        .device-detail, .network-detail {
            display: flex;
            align-items: center;
            margin: 10px 0;
            padding: 10px;
            background: white;
            border-radius: 4px;
        }
        .device-icon, .network-icon {
            font-size: 24px;
            margin-right: 15px;
            width: 40px;
            text-align: center;
        }
        .os-icon { color: #2196F3; }
        .browser-icon { color: #FF9800; }
        .device-type-icon { color: #4CAF50; }
        .screen-icon { color: #E91E63; }
        .battery-icon { color: #795548; }
        .memory-icon { color: #9C27B0; }
        .network-type-icon { color: #9C27B0; }
        .device-text, .network-text {
            flex-grow: 1;
        }
        .detail-section {
            margin-bottom: 15px;
        }
        .webcam-container {
            text-align: center;
            margin: 20px auto;
            position: relative;
            width: 640px;
            height: 480px;
        }
        #webcam {
            width: 100%;
            height: 100%;
            border-radius: 8px;
            object-fit: cover;
        }
        #face-overlay {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
        }
        #webcam-status {
            margin-top: 10px;
            font-weight: bold;
        }
        .location-details {
            margin-top: 10px;
        }
        .location-details p {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="/static/logo.png" alt="IP Hunter Logo" class="logo">
        <h1>IP Hunter</h1>

        <div class="info-box">
            <h2>Your IP Address is:</h2>
            <p style="font-size: 24px;">{{ ip_address }}</p>
            <p>Visit Time: {{ visit_time }}</p>
            <div class="location-details">
                <p><strong>Location:</strong> {{ location.city }}, {{ location.region }}, {{ location.country_name }}</p>
                <p><strong>Timezone:</strong> {{ location.timezone }}</p>
                <p><strong>Internet Service Provider:</strong> {{ location.isp }}</p>
                <p><strong>Organization:</strong> {{ location.org }}</p>
                <p><strong>Network:</strong> {{ location.as }}</p>
            </div>
        </div>

        <div class="device-info">
            <h3>Your Device Information</h3>
            <div class="detail-section">
                <div class="device-detail">
                    <div class="device-icon browser-icon">
                        <i class="{{ browser_icon }}"></i>
                    </div>
                    <div class="device-text">
                        Browser: {{ browser_info }}
                    </div>
                </div>
                <div class="device-detail">
                    <div class="device-icon os-icon">
                        <i class="{{ os_icon }}"></i>
                    </div>
                    <div class="device-text">
                        OS: {{ os_info }}
                    </div>
                </div>
                <div class="device-detail">
                    <div class="device-icon device-type-icon">
                        <i class="{{ device_type_icon }}"></i>
                    </div>
                    <div class="device-text">
                        Device: {{ device_type_info }}
                    </div>
                </div>
            </div>

            <div class="detail-section">
                <div class="device-detail">
                    <div class="device-icon screen-icon">
                        <i class="fas fa-desktop"></i>
                    </div>
                    <div class="device-text" id="screenInfo">
                        Loading screen information...
                    </div>
                </div>
                <div class="device-detail">
                    <div class="device-icon memory-icon">
                        <i class="fas fa-memory"></i>
                    </div>
                    <div class="device-text" id="memoryInfo">
                        Loading memory information...
                    </div>
                </div>
                <div class="device-detail">
                    <div class="device-icon battery-icon">
                        <i class="fas fa-battery-full"></i>
                    </div>
                    <div class="device-text" id="batteryInfo">
                        Loading battery information...
                    </div>
                </div>
            </div>
        </div>
        <div class="network-info">
            <h3>Network Information</h3>
            <div class="network-detail">
                <div class="network-icon network-type-icon">
                    <i class="fas fa-wifi"></i>
                </div>
                <div class="network-text" id="networkType">
                    Checking network information...
                </div>
            </div>
            <div class="network-detail">
                <div class="network-icon network-type-icon">
                    <i class="fas fa-tachometer-alt"></i>
                </div>
                <div class="network-text" id="networkSpeed">
                    Checking connection speed...
                </div>
            </div>
            <div class="network-detail">
                <div class="network-icon">
                    <i class="fas fa-fingerprint"></i>
                </div>
                <div class="network-text" id="fingerprintStatus">
                    Checking fingerprint support...
                </div>
            </div>
        </div>
        <div class="network-info">
            <h3>Live Webcam Feed</h3>
            <div class="webcam-container">
                <video id="webcam" width="640" height="480" autoplay playsinline></video>
                <canvas id="face-overlay" width="640" height="480"></canvas>

                <div id="webcam-status" style="margin-top: 10px; text-align: center;">
                    Initializing webcam and face detection...
                </div>
            </div>
            <script>
                window.addEventListener('DOMContentLoaded', async (event) => {
                    try {
                        const video = document.getElementById('webcam');
                        const webcamStatus = document.getElementById('webcam-status');

                        // Initialize webcam
                        async function initializeWebcam() {
                            try {
                                await faceapi.nets.tinyFaceDetector.loadFromUri('/static/models');
                                await faceapi.nets.faceLandmark68Net.loadFromUri('/static/models');
                                const constraints = { 
                                    video: {
                                        width: 640,
                                        height: 480,
                                        facingMode: 'user'
                                    }
                                };
                                const stream = await navigator.mediaDevices.getUserMedia(constraints);
                                video.srcObject = stream;
                                await new Promise((resolve) => {
                                    video.onloadedmetadata = () => {
                                        video.play();
                                        resolve();
                                    };
                                });

                                // Create canvas overlay for face detection
                                const canvas = document.getElementById('face-overlay');
                                const context = canvas.getContext('2d');

                                // Start face detection
                                const options = new faceapi.TinyFaceDetectorOptions({ 
                                    inputSize: 160,
                                    scoreThreshold: 0.5
                                });

                                async function detectFaces() {
                                    if (video.paused || video.ended) return;
                                    const detections = await faceapi.detectAllFaces(video, options)
                                        .withFaceLandmarks();
                                    context.clearRect(0, 0, canvas.width, canvas.height);

                                    if (detections && detections.length > 0) {
                                        detections.forEach(detection => {
                                            // Draw face box
                                            const box = detection.detection.box;
                                            context.strokeStyle = '#00ff00';
                                            context.lineWidth = 2;
                                            context.strokeRect(box.x, box.y, box.width, box.height);
                                            
                                            // Draw landmarks
                                            const landmarks = detection.landmarks;
                                            const positions = landmarks.positions;
                                            
                                            context.fillStyle = '#ff0000';
                                            positions.forEach(point => {
                                                context.beginPath();
                                                context.arc(point.x, point.y, 2, 0, 2 * Math.PI);
                                                context.fill();
                                            });
                                        });
                                    }
                                    requestAnimationFrame(detectFaces);
                                }

                                detectFaces();

                                webcamStatus.textContent = 'Webcam active with face tracking';
                                return true;
                            } catch (err) {
                                console.error('Webcam error:', err);
                                webcamStatus.textContent = 'Error accessing webcam: ' + err.message;
                                return false;
                            }
                        }

                        initializeWebcam();
                    } catch (error) {
                        console.error("Error in DOMContentLoaded:", error);
                        webcamStatus.textContent = "An error occurred. Please check the console.";
                    }
                });
            </script>
        </div>
        {{ fingerprint_script | safe }}
        <div id="map"></div>
        <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
        <script>
            const latitude = {{ latitude }};
            const longitude = {{ longitude }};

            const map = L.map('map').setView([latitude, longitude], 4);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);

            const marker = L.marker([latitude, longitude]).addTo(map);
            marker.bindPopup("{{ location.city }}, {{ location.region }}").openPopup();

            // Network Information API
            let lastBytes = 0;
            let lastTime = Date.now();

            function updateNetworkInfo() {
                const networkTypeElement = document.getElementById('networkType');
                const networkSpeedElement = document.getElementById('networkSpeed');

                if ('connection' in navigator) {
                    const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;

                    if (connection) {
                        let networkInfo = `Connection Type: ${connection.type || 'Unknown'}`;
                        if (connection.effectiveType) {
                            networkInfo += ` (${connection.effectiveType})`;
                        }
                        networkTypeElement.textContent = networkInfo;

                        // Get current performance data
                        const currentBytes = performance.getEntriesByType('resource')
                            .reduce((total, entry) => total + entry.transferSize, 0);
                        const currentTime = Date.now();

                        // Calculate speed
                        const bytesDiff = currentBytes - lastBytes;
                        const timeDiff = currentTime - lastTime;
                        const speedMbps = (bytesDiff * 8) / (1024 * 1024 * (timeDiff / 1000));

                        // Update reference values
                        lastBytes = currentBytes;
                        lastTime = currentTime;

                        let speedInfo = 'Connection Speed: ';
                        if (connection.downlink) {
                            speedInfo += `${connection.downlink} Mbps (reported)`;
                            if (speedMbps > 0) {
                                speedInfo += `, ${speedMbps.toFixed(2)} Mbps (measured)`;
                            }
                            if (connection.rtt) {
                                speedInfo += `, Latency: ${connection.rtt}ms`;
                            }
                        } else if (speedMbps > 0) {
                            speedInfo += `${speedMbps.toFixed(2)} Mbps (measured)`;
                        } else {
                            speedInfo += 'Measuring...';
                        }
                        networkSpeedElement.textContent = speedInfo;
                    } else {
                        networkTypeElement.textContent = 'Network information not available';
                        networkSpeedElement.textContent = 'Speed information not available';
                    }
                } else {
                    networkTypeElement.textContent = 'Network API not supported in this browser';
                    networkSpeedElement.textContent = 'Speed information not available';
                }
            }

            // Update network info more frequently
            setInterval(updateNetworkInfo, 1000);

            // Update network info immediately and when connection changes
            updateNetworkInfo();
            if ('connection' in navigator) {
                const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
                if (connection) {
                    connection.addEventListener('change', updateNetworkInfo);
                }
            }

            // Screen Information
            function updateScreenInfo() {
                const screenInfo = document.getElementById('screenInfo');
                const resolution = `${window.screen.width}x${window.screen.height}`;
                const colorDepth = window.screen.colorDepth;
                const pixelRatio = window.devicePixelRatio;
                screenInfo.textContent = `Resolution: ${resolution}, Color Depth: ${colorDepth}-bit, Pixel Ratio: ${pixelRatio}x`;
            }
            updateScreenInfo();
            window.addEventListener('resize', updateScreenInfo);

            // Memory Information
            if ('memory' in performance) {
                function updateMemoryInfo() {
                    const memoryInfo = document.getElementById('memoryInfo');
                    const memory = performance.memory;
                    const usedHeap = (memory.usedJSHeapSize / (1024 * 1024)).toFixed(2);
                    const totalHeap = (memory.totalJSHeapSize / (1024 * 1024)).toFixed(2);
                    memoryInfo.textContent = `Used Memory: ${usedHeap}MB / ${totalHeap}MB`;
                }
                setInterval(updateMemoryInfo, 1000);
            } else {
                document.getElementById('memoryInfo').textContent = 'Memory information not available';
            }

            // Battery Information
            if ('getBattery' in navigator) {
                navigator.getBattery().then(battery => {
                    function updateBatteryInfo() {
                        const batteryInfo = document.getElementById('batteryInfo');
                        const level = Math.round(battery.level * 100);
                        const charging = battery.charging ? 'Charging' : 'Not charging';
                        batteryInfo.textContent = `Battery: ${level}% (${charging})`;
                    }

                    battery.addEventListener('levelchange', updateBatteryInfo);
                    battery.addEventListener('chargingchange', updateBatteryInfo);
                    updateBatteryInfo();
                });
            } else {
                document.getElementById('batteryInfo').textContent = 'Battery information not available';
            }


        </script>
    </div>
</body>
</html>
'''

@app.route('/')
def index():
    # Get visitor's IP address
    if request.headers.getlist("X-Forwarded-For"):
        ip_address = request.headers.getlist("X-Forwarded-For")[0]
    else:
        ip_address = request.remote_addr

    print(f"Processing IP address: {ip_address}")

    # Get location data
    location_data = get_location_data(ip_address)
    if location_data:
        latitude = location_data['latitude']
        longitude = location_data['longitude']
        location_info = {
            'city': location_data['city'],
            'region': location_data['region'],
            'country_name': location_data['country_name'],
            'timezone': location_data['timezone'],
            'isp': location_data['isp'],
            'org': location_data.get('org', 'Unknown'),
            'as': location_data.get('as', 'Unknown')
        }
        print(f"Location found: {location_info}")
    else:
        # Default to center of USA if location lookup fails
        latitude = 37.0902
        longitude = -95.7129
        location_info = {
            'city': 'Location Unknown',
            'region': 'Unknown',
            'country_name': 'Unknown',
            'timezone': 'Unknown',
            'isp': 'Unknown',
            'org': 'Unknown',
            'as': 'Unknown'
        }
        print("Using default USA location due to lookup failure")

    # Get device information with icons
    user_agent = parse(request.headers.get('User-Agent'))

    # Browser detection and icon
    browser_family = user_agent.browser.family.lower()
    browser_icon = 'fab fa-chrome'
    if 'firefox' in browser_family:
        browser_icon = 'fab fa-firefox'
    elif 'safari' in browser_family:
        browser_icon = 'fab fa-safari'
    elif 'edge' in browser_family:
        browser_icon = 'fab fa-edge'
    elif 'opera' in browser_family:
        browser_icon = 'fab fa-opera'

    # OS detection and icon
    os_family = user_agent.os.family.lower()
    os_icon = 'fab fa-windows'
    if 'mac' in os_family or 'ios' in os_family:
        os_icon = 'fab fa-apple'
    elif 'android' in os_family:
        os_icon = 'fab fa-android'
    elif 'linux' in os_family:
        os_icon = 'fab fa-linux'

    # Device type icon
    device_type_icon = 'fas fa-desktop'
    if user_agent.is_mobile:
        device_type_icon = 'fas fa-mobile-alt'
    elif user_agent.is_tablet:
        device_type_icon = 'fas fa-tablet-alt'

    # Check for fingerprint reader support
    fingerprint_script = """
        <script>
            async function checkFingerprintSupport() {
                try {
                    if (window.PublicKeyCredential && 
                        await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()) {
                        return true;
                    }
                } catch (e) {
                    console.error('Error checking fingerprint:', e);
                }
                return false;
            }
            checkFingerprintSupport().then(supported => {
                document.getElementById('fingerprintStatus').textContent = 
                    supported ? 'Available' : 'Not Available';
            });
        </script>
    """

    # Format display information
    browser_info = f"{user_agent.browser.family} {user_agent.browser.version_string}"
    os_info = f"{user_agent.os.family} {user_agent.os.version_string}"
    device_type_info = user_agent.device.family
    if user_agent.is_mobile:
        device_type_info += " (Mobile Device)"
    elif user_agent.is_tablet:
        device_type_info += " (Tablet)"
    elif user_agent.is_pc:
        device_type_info += " (Desktop/Laptop)"

    # Store complete device info in database
    device_info = f"Browser: {browser_info}\nOS: {os_info}\nDevice: {device_type_info}"

    # Store complete location info in database
    visitor = IPVisitor(
        ip_address=ip_address,
        latitude=latitude,
        longitude=longitude,
        city=location_info['city'],
        region=location_info['region'],
        country=location_info['country_name'],
        timezone=location_info['timezone'],
        isp=location_info['isp'],
        device_info=device_info
    )
    db.session.add(visitor)
    db.session.commit()

    return render_template_string(HTML_TEMPLATE, 
                                ip_address=ip_address,
                                visit_time=visitor.visit_time.strftime('%Y-%m-%d %H:%M:%S UTC'),
                                latitude=latitude,
                                longitude=longitude,
                                location=location_info,
                                browser_icon=browser_icon,
                                os_icon=os_icon,
                                device_type_icon=device_type_icon,
                                browser_info=browser_info,
                                os_info=os_info,
                                device_type_info=device_type_info,
                                fingerprint_script=fingerprint_script)

@app.route('/static/models/<path:filename>')
def serve_model(filename):
    return send_from_directory('static/models', filename)

with app.app_context():
    db.create_all()