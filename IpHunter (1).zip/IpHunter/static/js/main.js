document.addEventListener('DOMContentLoaded', function() {
    const locationText = document.querySelector('.location-text').textContent;
    const pingMarker = document.getElementById('location-ping');
    
    // Get the state from the location text
    const stateMatch = locationText.match(/,\s*([A-Z]{2})/);
    
    if (stateMatch && stateCoordinates[stateMatch[1]]) {
        const coords = stateCoordinates[stateMatch[1]];
        pingMarker.setAttribute('cx', coords.x);
        pingMarker.setAttribute('cy', coords.y);
        pingMarker.style.display = 'block';
    }
});
